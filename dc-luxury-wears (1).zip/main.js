// DC LUXURY WEARS - Core JS
function addToCart(id, name, price, image) {
    const formData = new FormData();
    formData.append('id', id);
    formData.append('name', name);
    formData.append('price', price);
    formData.append('image', image);

    fetch('cart-action.php?action=add', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if(data.status === 'success') {
            document.getElementById('cart-count').innerText = data.count;
            alert(name + ' added to your selection.');
        }
    })
    .catch(err => console.error('Error:', err));
}

// Chatbot functionality
async function sendChatMessage() {
    const input = document.getElementById('chat-input');
    const msg = input.value.trim();
    if(!msg) return;

    appendMessage('user', msg);
    input.value = '';

    try {
        const res = await fetch('chat.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({message: msg})
        });
        const data = await res.json();
        appendMessage('bot', data.text);
    } catch(e) {
        appendMessage('bot', "I'm sorry, I'm currently unavailable. Reach us on WhatsApp!");
    }
}

function appendMessage(role, text) {
    const container = document.getElementById('chat-messages');
    if(!container) return;
    const div = document.createElement('div');
    div.className = `flex ${role === 'user' ? 'justify-end' : 'justify-start'} mb-4`;
    div.innerHTML = `<div class="${role === 'user' ? 'bg-gold-500 text-black' : 'bg-white/10 text-white'} p-3 rounded-xl max-w-[80%] text-xs font-medium uppercase tracking-tighter">${text}</div>`;
    container.appendChild(div);
    container.scrollTop = container.scrollHeight;
}
