<?php 
require_once 'includes/db.php';
include 'includes/header.php';

// Fetch featured products
$stmt = $pdo->query("SELECT * FROM products LIMIT 4");
$featured_products = $stmt->fetchAll();
?>

<!-- Hero Section -->
<section class="relative h-screen overflow-hidden">
    <div class="absolute inset-0">
        <img src="https://images.unsplash.com/photo-1441984904996-e0b6ba687e04?q=80&w=2070" class="w-full h-full object-cover opacity-60">
        <div class="absolute inset-0 bg-gradient-to-r from-black via-black/40 to-transparent"></div>
    </div>
    <div class="relative h-full max-w-7xl mx-auto px-6 flex flex-col justify-center">
        <h4 class="gold-text font-bold uppercase tracking-[0.3em] mb-4 text-sm animate-pulse text-white">Exclusive Collection 2026</h4>
        <h1 class="text-6xl md:text-8xl font-display font-bold leading-tight mb-8">LUXURY FASHION <br><span class="gold-text">REDEFINED</span></h1>
        <p class="text-gray-300 max-w-xl text-lg mb-10 leading-relaxed uppercase tracking-tighter">Premium wears, accessories, and gadgets curated for the Nigerian elite.</p>
        <div class="flex flex-wrap gap-4">
            <a href="shop.php" class="bg-gold-500 text-black px-10 py-4 font-bold uppercase tracking-widest hover:bg-gold-400 transition-all flex items-center group">
                Shop Now <i data-lucide="arrow-right" class="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform"></i>
            </a>
            <a href="about.php" class="border border-white/20 bg-white/5 backdrop-blur-md px-10 py-4 font-bold uppercase tracking-widest hover:bg-white/10 transition-all">Explore Story</a>
        </div>
    </div>
</section>

<!-- Featured Categories -->
<section class="py-24 bg-black">
    <div class="max-w-7xl mx-auto px-6">
        <div class="text-center mb-16">
            <h2 class="text-3xl font-display font-bold gold-text uppercase tracking-widest mb-4">The Collections</h2>
            <div class="w-24 h-1 bg-gold-500 mx-auto"></div>
        </div>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <?php 
            $categories = ['Men Fashion', 'Women Fashion', 'Watches', 'Accessories'];
            foreach($categories as $cat): ?>
                <a href="shop.php?category=<?php echo $cat; ?>" class="group block relative aspect-[3/4] overflow-hidden border border-white/5">
                    <img src="https://images.unsplash.com/photo-1617137984095-74e4e5e3613f?w=800" class="w-full h-full object-cover grayscale group-hover:grayscale-0 group-hover:scale-110 transition-all duration-700">
                    <div class="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-colors"></div>
                    <div class="absolute bottom-6 left-6 right-6 text-center">
                        <h3 class="text-sm font-bold uppercase tracking-widest text-white leading-relaxed"><?php echo $cat; ?></h3>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Featured Products -->
<section class="py-24 luxury-gradient">
    <div class="max-w-7xl mx-auto px-6">
        <div class="flex justify-between items-end mb-16">
            <div>
                <h2 class="text-3xl font-display font-bold uppercase tracking-widest gold-text">Signature Pieces</h2>
                <p class="text-gray-400 uppercase text-[10px] tracking-widest mt-2">Crafted for the sophisticated</p>
            </div>
            <a href="shop.php" class="text-gold-500 uppercase text-xs font-bold tracking-widest hover:underline">View All</a>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            <?php foreach($featured_products as $product): ?>
                <div class="group">
                    <div class="relative aspect-square overflow-hidden bg-white/5 border border-white/10">
                        <img src="<?php echo $product['image']; ?>" alt="<?php echo $product['name']; ?>" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500">
                        <div class="absolute top-4 right-4 flex flex-col space-y-2 translate-x-12 group-hover:translate-x-0 transition-transform duration-300">
                            <button class="p-2 bg-white text-black hover:bg-gold-500 transition-colors"><i data-lucide="heart" class="w-4 h-4"></i></button>
                        </div>
                        <a href="product.php?id=<?php echo $product['id']; ?>" class="absolute bottom-0 left-0 w-full bg-gold-500 text-black py-3 font-bold uppercase text-xs tracking-widest translate-y-full group-hover:translate-y-0 transition-transform duration-300 text-center">Quick View</a>
                    </div>
                    <div class="mt-4 space-y-1">
                        <h3 class="text-sm font-bold uppercase group-hover:gold-text transition-colors text-white"><?php echo $product['name']; ?></h3>
                        <p class="text-gold-500 font-bold">₦<?php echo number_format($product['price']); ?></p>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
