<?php 
session_start();
include 'includes/header.php';
$cart = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];
$total = 0;
foreach($cart as $item) { $total += $item['price'] * $item['quantity']; }
?>

<div class="pt-32 pb-24 bg-black min-h-screen text-white">
    <div class="max-w-7xl mx-auto px-6">
        <h1 class="text-4xl font-display font-bold gold-text uppercase tracking-widest mb-12">Your Selections</h1>

        <?php if(empty($cart)): ?>
            <div class="text-center py-24">
                <i data-lucide="shopping-bag" class="w-16 h-16 text-gray-700 mx-auto mb-6"></i>
                <h2 class="text-2xl font-display font-bold uppercase tracking-widest mb-4">Your Bag is Empty</h2>
                <a href="shop.php" class="inline-block bg-gold-500 text-black px-12 py-4 font-bold uppercase tracking-widest hover:bg-gold-400">Continue Shopping</a>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-12 text-white">
                <div class="lg:col-span-2 space-y-8">
                    <?php foreach($cart as $id => $item): ?>
                        <div class="flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-6 bg-white/5 border border-white/10 p-6">
                            <div class="w-24 h-24 overflow-hidden border border-white/10">
                                <img src="<?php echo $item['image']; ?>" class="w-full h-full object-cover">
                            </div>
                            <div class="flex-1 text-center sm:text-left">
                                <h3 class="font-bold uppercase tracking-widest"><?php echo $item['name']; ?></h3>
                                <p class="text-gold-500 font-bold">₦<?php echo number_format($item['price']); ?></p>
                            </div>
                            <form action="cart-action.php?action=update" method="POST" class="flex items-center space-x-4 border border-white/10 px-4 py-2">
                                <input type="hidden" name="id" value="<?php echo $id; ?>">
                                <input type="number" name="quantity" value="<?php echo $item['quantity']; ?>" class="bg-transparent w-8 text-center" onchange="this.form.submit()">
                            </form>
                            <div class="text-right sm:w-24">
                                <p class="font-bold">₦<?php echo number_format($item['price'] * $item['quantity']); ?></p>
                                <form action="cart-action.php?action=remove" method="POST">
                                    <input type="hidden" name="id" value="<?php echo $id; ?>">
                                    <button type="submit" class="text-red-500 hover:text-red-400 mt-2"><i data-lucide="trash-2" class="w-4 h-4"></i></button>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <div>
                    <div class="bg-white/5 border border-white/10 p-8 space-y-6 sticky top-32">
                        <h3 class="text-xl font-display font-bold uppercase mb-4 border-b border-white/10 pb-4">Summary</h3>
                        <div class="flex justify-between text-sm">
                            <span class="text-gray-400 uppercase">Subtotal</span>
                            <span class="font-bold">₦<?php echo number_format($total); ?></span>
                        </div>
                        <div class="border-t border-white/10 pt-4 flex justify-between items-end">
                            <span class="text-sm font-bold uppercase tracking-widest">Total</span>
                            <span class="text-2xl font-bold gold-text">₦<?php echo number_format($total); ?></span>
                        </div>
                        <a href="checkout.php" class="block w-full bg-gold-500 text-black py-4 font-bold uppercase tracking-widest text-center hover:bg-gold-400 transition-colors">Secure Checkout</a>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
