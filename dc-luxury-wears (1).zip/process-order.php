<?php
// DC LUXURY WEARS - Order Processor
session_start();
require_once 'includes/db.php';

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $state = $_POST['state'];
    $city = $_POST['city'];
    $address = $_POST['address'];
    $payment_method = $_POST['payment'];
    $total = $_POST['total'];

    // 1. Save to Database
    try {
        $stmt = $pdo->prepare("INSERT INTO orders (total_amount, delivery_address, phone, payment_method) VALUES (?, ?, ?, ?)");
        $stmt->execute([$total, "$address, $city, $state", $phone, $payment_method]);
        $order_id = $pdo->lastInsertId();

        // 2. Handle Payment Gateway Redirects (Mock Logic)
        if($payment_method === 'paystack') {
            // In a real scenario, you would redirect to Paystack here
            // header("Location: https://paystack.com/pay/dc-luxury-order-$order_id");
            // exit;
        }

        // 3. Success Notification
        unset($_SESSION['cart']);
        echo "<script>alert('Order Successfully Received! Your reference is #DC$order_id. We will contact you shortly.'); window.location.href='index.php';</script>";
        
    } catch (PDOException $e) {
        die("Error processing order: " . $e->getMessage());
    }
}
?>
