-- DC LUXURY WEARS Database Schema
-- For use with MySQL 8.0+

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

-- Table: users
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL UNIQUE,
  `password` varchar(255) NOT NULL,
  `role` enum('user','admin') DEFAULT 'user',
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: categories
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: products
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `description` text,
  `image` varchar(255) DEFAULT NULL,
  `stock` int(11) DEFAULT 0,
  `rating` decimal(2,1) DEFAULT 5.0,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`category_id`) REFERENCES `categories`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: orders
CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `status` enum('pending','processing','shipped','delivered','cancelled') DEFAULT 'pending',
  `delivery_address` text NOT NULL,
  `phone` varchar(20) NOT NULL,
  `payment_method` varchar(50) NOT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: order_items
CREATE TABLE `order_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`),
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Sample Data
INSERT INTO `categories` (`name`) VALUES 
('Men Fashion'), ('Women Fashion'), ('Shoes'), ('Watches'), ('Bags'), ('Perfumes'), ('Accessories'), ('Gadgets');

INSERT INTO `products` (`category_id`, `name`, `price`, `description`, `image`, `rating`) VALUES 
(4, 'DC Imperial Chronograph', 125000.00, 'Premium luxury wristwatch with gold accents.', 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800', 4.8),
(1, 'Royal Velvet Men\'s Suit', 85000.00, 'Handcrafted velvet suit for special occasions.', 'https://images.unsplash.com/photo-1594932224828-b4b05a832921?w=800', 4.9),
(2, 'Luxury Silk Evening Gown', 95000.00, 'Elegant silk gown for the modern woman.', 'https://images.unsplash.com/photo-1566174053879-31528523f8ae?w=800', 4.7),
(8, 'Gold-Plated Luxury Smartphone', 850000.00, '24k gold-plated limited edition smartphone.', 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=800', 5.0),
(3, 'Elite Leather Brogues', 45000.00, 'Hand-stitched Italian leather shoes.', 'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=800', 4.8),
(5, 'Midnight Velvet Clutch', 35000.00, 'Sophisticated evening bag for luxury events.', 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=800', 4.6);

COMMIT;
