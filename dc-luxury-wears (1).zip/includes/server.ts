import express from "express";
import path from "path";
import cors from "cors";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import fs from "fs/promises";
import { fileURLToPath } from "url";
import dotenv from "dotenv";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = 3000;
const DB_PATH = path.join(__dirname, "db.json");

// Initialize Gemini
const ai = new GoogleGenAI({ 
  apiKey: process.env.GEMINI_API_KEY || "",
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

async function ensureDb() {
  try {
    await fs.access(DB_PATH);
  } catch {
    const initialDb = {
      users: [],
      products: [
        {
          id: "1",
          name: "DC Imperial Chronograph",
          category: "Watches",
          price: 125000,
          image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800",
          description: "Premium luxury wristwatch with gold accents.",
          rating: 4.8
        },
        {
          id: "2",
          name: "Royal Velvet Men's Suit",
          category: "Men Fashion",
          price: 85000,
          image: "https://images.unsplash.com/photo-1594932224828-b4b05a832921?w=800",
          description: "Handcrafted velvet suit for special occasions.",
          rating: 4.9
        },
        {
          id: "3",
          name: "Luxury Silk Evening Gown",
          category: "Women Fashion",
          price: 95000,
          image: "https://images.unsplash.com/photo-1566174053879-31528523f8ae?w=800",
          description: "Elegant silk gown for the modern woman.",
          rating: 4.7
        },
        {
           id: "4",
           name: "Gold-Plated Luxury Smartphone",
           category: "Gadgets",
           price: 850000,
           image: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=800",
           description: "24k gold-plated limited edition smartphone.",
           rating: 5.0
        }
      ],
      categories: ["Men Fashion", "Women Fashion", "Shoes", "Watches", "Bags", "Perfumes", "Accessories", "Gadgets"],
      orders: [],
      cart: [],
      reviews: []
    };
    await fs.writeFile(DB_PATH, JSON.stringify(initialDb, null, 2));
  }
}

async function startServer() {
  await ensureDb();
  const app = express();
  app.use(cors());
  app.use(express.json());

  // API Routes
  app.get("/api/products", async (req, res) => {
    const db = JSON.parse(await fs.readFile(DB_PATH, "utf-8"));
    res.json(db.products);
  });

  app.get("/api/categories", async (req, res) => {
    const db = JSON.parse(await fs.readFile(DB_PATH, "utf-8"));
    res.json(db.categories);
  });

  // Gemini Chatbot Route
  app.post("/api/chat", async (req, res) => {
    const { message, history = [] } = req.body;
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: [
          { role: "user", parts: [{ text: `You are the DC LUXURY WEARS Assistant. 
            DC LUXURY WEARS is a luxury fashion brand in Nigeria.
            We sell Men wears, Women wears, Shoes, Wristwatches, Bags, Accessories, Perfumes, Luxury gadgets.
            Currency: Nigerian Naira (₦).
            WhatsApp: +2347030146879.
            Location: Shop Address in Google Maps link provided in contact.
            Be polite, luxurious, and helpful. 
            Help users track orders, recommend products, and answer FAQs.
            Redirect to WhatsApp for direct purchase support if needed.
            User Message: ${message}` }] }
        ],
      });
      res.json({ text: response.text });
    } catch (error) {
      console.error("Gemini Error:", error);
      res.status(500).json({ error: "Failed to communicate with AI" });
    }
  });

  // Vite middlewear or static files
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
