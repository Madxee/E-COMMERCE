<!-- DC LUXURY WEARS - Header -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DC LUXURY WEARS - Luxury Fashion Redefined</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Playfair+Display:ital,wght@0,400;0,700;1,400&display=swap" rel="stylesheet">
    <!-- Lucide Icons -->
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        body { font-family: 'Inter', sans-serif; background: black; color: white; }
        .font-display { font-family: 'Playfair Display', serif; }
        .gold-text { color: #d4af37; }
        .bg-gold { background-color: #d4af37; }
        .border-gold { border-color: #d4af37; }
        .luxury-gradient { background: linear-gradient(135deg, #000 0%, #1a1a1a 100%); }
        .glass-morphism { background: rgba(255, 255, 255, 0.05); backdrop-filter: blur(10px); border: 1px solid rgba(255, 255, 255, 0.1); }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav id="nav" class="fixed top-0 w-full z-50 transition-all duration-300 bg-transparent py-6">
        <div class="max-w-7xl mx-auto px-6 flex justify-between items-center">
            <a href="index.php" class="text-2xl font-display font-bold gold-text tracking-widest uppercase">
                DC Luxury
            </a>

            <!-- Desktop Menu -->
            <div class="hidden md:flex space-x-8 items-center text-sm uppercase tracking-tighter">
                <a href="index.php" class="hover:text-gold-500 transition-colors">Home</a>
                <a href="shop.php" class="hover:text-gold-500 transition-colors">Shop</a>
                <a href="about.php" class="hover:text-gold-500 transition-colors">About</a>
                <a href="contact.php" class="hover:text-gold-500 transition-colors">Contact</a>
            </div>

            <div class="flex items-center space-x-6">
                <i data-lucide="search" class="w-5 h-5 cursor-pointer hover:text-gold-500 transition-colors"></i>
                <a href="cart.php" class="relative">
                    <i data-lucide="shopping-cart" class="w-5 h-5 hover:text-gold-500 transition-colors"></i>
                    <span id="cart-count" class="absolute -top-2 -right-2 bg-gold-500 text-black text-[10px] font-bold px-1.5 rounded-full">0</span>
                </a>
                <a href="login.php" class="hidden md:block">
                    <i data-lucide="user" class="w-5 h-5 hover:text-gold-500 transition-colors"></i>
                </a>
                <button class="md:hidden" id="menu-btn">
                    <i data-lucide="menu" class="w-6 h-6"></i>
                </button>
            </div>
        </div>
    </nav>

    <script>
        // Sticky Navbar
        window.addEventListener('scroll', () => {
            const nav = document.getElementById('nav');
            if (window.scrollY > 20) {
                nav.classList.add('bg-black/90', 'backdrop-blur-md', 'border-b', 'border-white/10', 'py-4');
                nav.classList.remove('bg-transparent', 'py-6');
            } else {
                nav.classList.remove('bg-black/90', 'backdrop-blur-md', 'border-b', 'border-white/10', 'py-4');
                nav.classList.add('bg-transparent', 'py-6');
            }
        });
    </script>
