<?php
// DC LUXURY WEARS - Database Configuration
// Use this for cPanel, XAMPP, or Localhost

$host = 'localhost';
$dbname = 'dc_luxury_db'; 
$username = 'root'; // Change to your cPanel DB username
$password = '';     // Change to your cPanel DB password

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERR_MODE, PDO::ERR_MODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // In production, log this instead of showing
    die("Database connection failed: " . $e->getMessage());
}
?>
