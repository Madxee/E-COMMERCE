<!-- DC LUXURY WEARS - Footer -->
    <footer class="bg-black border-t border-white/10 pt-20 pb-10 mt-20">
        <div class="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-4 gap-12">
            <div class="space-y-6">
                <h3 class="text-xl font-display gold-text font-bold uppercase tracking-widest">DC Luxury Wears</h3>
                <p class="text-gray-400 text-sm leading-relaxed">
                    Redefining luxury fashion in Nigeria. Premium wears, accessories, and gadgets for the sophisticated lifestyle.
                </p>
                <div class="flex space-x-4">
                    <a href="#" class="p-2 border border-white/10 rounded-full hover:border-gold-500 transition-colors text-white"><i data-lucide="facebook" class="w-4 h-4"></i></a>
                    <a href="#" class="p-2 border border-white/10 rounded-full hover:border-gold-500 transition-colors text-white"><i data-lucide="instagram" class="w-4 h-4"></i></a>
                    <a href="#" class="p-2 border border-white/10 rounded-full hover:border-gold-500 transition-colors text-white"><i data-lucide="twitter" class="w-4 h-4"></i></a>
                </div>
            </div>

            <div class="space-y-6">
                <h4 class="text-sm font-bold uppercase tracking-widest gold-text text-white">Quick Links</h4>
                <ul class="space-y-3 text-sm text-gray-400 uppercase tracking-tighter">
                    <li><a href="shop.php" class="hover:text-gold-500 transition-colors">Shop All</a></li>
                    <li><a href="about.php" class="hover:text-gold-500 transition-colors">Our Story</a></li>
                    <li><a href="contact.php" class="hover:text-gold-500 transition-colors">Contact Us</a></li>
                    <li><a href="track.php" class="hover:text-gold-500 transition-colors">Order Tracking</a></li>
                </ul>
            </div>

            <div class="space-y-6">
                <h4 class="text-sm font-bold uppercase tracking-widest gold-text">Contact</h4>
                <ul class="space-y-4 text-sm text-gray-400">
                    <li class="flex items-start space-x-3">
                        <i data-lucide="map-pin" class="w-5 h-5 gold-text shrink-0"></i>
                        <span>Suite 12, Luxury Plaza, Lagos, Nigeria</span>
                    </li>
                    <li class="flex items-center space-x-3">
                        <i data-lucide="phone" class="w-5 h-5 gold-text shrink-0"></i>
                        <span>+234 703 014 6879</span>
                    </li>
                </ul>
            </div>

            <div class="space-y-6">
                <h4 class="text-sm font-bold uppercase tracking-widest gold-text">Newsletter</h4>
                <div class="flex border border-white/10 p-1">
                    <input type="email" placeholder="EMAIL" class="bg-transparent text-xs p-2 outline-none w-full uppercase">
                    <button class="bg-gold-500 text-black px-4 py-2 text-xs font-bold font-white uppercase">Join</button>
                </div>
            </div>
        </div>
        
        <div class="max-w-7xl mx-auto px-6 mt-20 pt-8 border-t border-white/5 text-center text-[10px] text-gray-500 uppercase tracking-widest">
            &copy; 2026 DC LUXURY WEARS — ALL RIGHTS RESERVED.
        </div>
    </footer>

    <!-- WhatsApp Floating Button -->
    <a href="https://wa.me/2347030146879?text=Hello DC LUXURY WEARS, I want to place an order." 
       target="_blank" 
       class="fixed bottom-6 right-6 z-50 p-4 bg-green-500 text-white rounded-full shadow-2xl hover:scale-110 transition-transform">
        <svg viewBox="0 0 24 24" class="w-6 h-6 fill-current">
            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
        </svg>
    </a>

    <!-- Initialize Lucide -->
    <script>lucide.createIcons();</script>
</body>
</html>
