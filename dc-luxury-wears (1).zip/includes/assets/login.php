<?php
session_start();
require_once '../includes/db.php';

$error = '';
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // For luxury security, normally you'd verify hash. 
    // This is a bootstrap version.
    if($email === 'admin@dcluxury.com' && $password === 'admin123') {
        $_SESSION['admin_logged_in'] = true;
        header('Location: index.php');
        exit;
    } else {
        $error = 'Invalid Credentials';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>DC LUXURY - Admin Access</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>body { background: black; color: white; }</style>
</head>
<body class="flex items-center justify-center h-screen px-6">
    <div class="w-full max-w-md bg-white/5 border border-white/10 p-12 space-y-8">
        <div class="text-center">
            <h1 class="text-2xl font-serif gold-text uppercase tracking-widest font-bold">Admin Portal</h1>
            <p class="text-[10px] text-gray-500 uppercase mt-2">Secure entry for staff only</p>
        </div>
        
        <?php if($error): ?>
            <p class="text-red-500 text-xs text-center uppercase tracking-widest"><?php echo $error; ?></p>
        <?php endif; ?>

        <form action="login.php" method="POST" class="space-y-6">
            <input type="email" name="email" placeholder="ADMIN EMAIL" required class="w-full bg-transparent border-b border-white/20 py-4 text-xs tracking-widest outline-none focus:border-gold-500 text-white">
            <input type="password" name="password" placeholder="PASSWORD" required class="w-full bg-transparent border-b border-white/20 py-4 text-xs tracking-widest outline-none focus:border-gold-500 text-white">
            <button type="submit" class="w-full bg-white text-black py-4 font-bold uppercase text-[10px] tracking-widest hover:bg-gold-500 transition-colors">Authorize Entry</button>
        </form>
    </div>
</body>
</html>
