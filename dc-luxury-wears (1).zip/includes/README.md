# DC LUXURY WEARS - Deployment Guide (cPanel & XAMPP)

This project is a complete luxury e-commerce platform built specifically for **PHP and MySQL** environments.

## 🚀 cPanel / Shared Hosting Installation
1.  **Upload Files**: Upload all files from this project to your `public_html` directory (or a subdirectory).
2.  **Database Setup**:
    *   Log in to cPanel and go to **MySQL® Databases**.
    *   Create a new database named `dc_luxury_db`.
    *   Create a new user, set a password, and add the user to the database with all privileges.
3.  **Import SQL**:
    *   Go to **phpMyAdmin** in cPanel.
    *   Select your database and click **Import**.
    *   Choose the `database.sql` file from this project and click **Execute**.
4.  **Configure Connection**:
    *   Edit `/includes/db.php`.
    *   Update `$username`, `$password`, and `$dbname` with your cPanel database details.

## 💻 XAMPP / Localhost Installation
1.  **Copy Files**: Place the project folder inside `C:/xampp/htdocs/`.
2.  **Start Services**: Open XAMPP Control Panel and start **Apache** and **MySQL**.
3.  **Import SQL**:
    *   Go to `http://localhost/phpmyadmin`.
    *   Create a database named `dc_luxury_db`.
    *   Import `database.sql`.
4.  **Configure Connection**:
    *   The default settings in `/includes/db.php` (root/no password) should work out of the box for XAMPP.

## 🔑 Admin Access
*   **URL**: `yourdomain.com/admin/login.php`
*   **Default Email**: `admin@dcluxury.com`
*   **Default Password**: `admin123`

## 🛠 Tech Stack
*   **Backend**: PHP 8.0+
*   **Database**: MySQL
*   **Frontend**: HTML5, Tailwind CSS (CDN), JavaScript (AJAX)
*   **Icons**: Lucide Icons
*   **AI Support**: Chatbot ready for integration via Gemini API.

© 2026 DC LUXURY WEARS — All Rights Reserved.
