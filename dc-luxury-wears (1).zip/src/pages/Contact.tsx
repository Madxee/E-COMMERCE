import { Mail, Phone, MapPin, Clock, Send } from "lucide-react";
import { motion } from "motion/react";

export default function Contact() {
  return (
    <div className="pt-32 pb-24 bg-black min-h-screen">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-20">
          <h1 className="text-4xl md:text-5xl font-display font-bold gold-text uppercase tracking-widest mb-6">Connect With Us</h1>
          <p className="text-gray-400 max-w-2xl mx-auto uppercase text-xs tracking-[0.2em] leading-loose">
            Reach out to our luxury concierge for personalized shopping assistance, bespoke orders, or business inquiries.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20">
          <div className="space-y-12">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-white/5 border border-white/10 p-8 space-y-4 hover:border-gold-500/50 transition-colors group">
                <div className="p-3 bg-gold-500/10 rounded-lg w-fit group-hover:bg-gold-500 group-hover:text-black transition-colors">
                  <Phone className="w-5 h-5" />
                </div>
                <h3 className="text-xs font-bold uppercase tracking-widest gold-text">Phone Support</h3>
                <p className="text-lg font-display">+234 703 014 6879</p>
                <p className="text-[10px] text-gray-500 uppercase">Available 24/7 for Elite Members</p>
              </div>

              <div className="bg-white/5 border border-white/10 p-8 space-y-4 hover:border-gold-500/50 transition-colors group">
                <div className="p-3 bg-gold-500/10 rounded-lg w-fit group-hover:bg-gold-500 group-hover:text-black transition-colors">
                  <Mail className="w-5 h-5" />
                </div>
                <h3 className="text-xs font-bold uppercase tracking-widest gold-text">Email Inquiries</h3>
                <p className="text-lg font-display">concierge@dcluxury.com</p>
                <p className="text-[10px] text-gray-500 uppercase">Response within 2 hours</p>
              </div>
            </div>

            <div className="bg-white/5 border border-white/10 p-8 space-y-6">
              <h3 className="text-xs font-bold uppercase tracking-widest gold-text flex items-center">
                <Clock className="w-4 h-4 mr-2" />
                Business Hours
              </h3>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between border-b border-white/5 pb-2">
                  <span className="text-gray-400 uppercase tracking-tighter">Monday - Friday</span>
                  <span className="font-bold">09:00 AM - 08:00 PM</span>
                </div>
                <div className="flex justify-between border-b border-white/5 pb-2">
                  <span className="text-gray-400 uppercase tracking-tighter">Saturday</span>
                  <span className="font-bold">10:00 AM - 06:00 PM</span>
                </div>
                <div className="flex justify-between border-b border-white/5 pb-2">
                  <span className="text-gray-400 uppercase tracking-tighter">Sunday</span>
                  <span className="font-bold">Closed</span>
                </div>
              </div>
            </div>

            <div className="bg-white/5 border border-white/10 overflow-hidden h-96 relative group">
              <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d126846.52936279641!2d3.31346087786435!3d6.524379291157143!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x103b8b2ae68280c1%3A0xdc9e87a397c7d60!2sLagos%2C%20Nigeria!5e0!3m2!1sen!2s!4v1715874620000!5m2!1sen!2s" 
                className="w-full h-full grayscale contrast-125 opacity-70 group-hover:opacity-100 group-hover:grayscale-0 transition-all duration-500" 
                style={{ border: 0 }} 
                allowFullScreen={true} 
                loading="lazy" 
                referrerPolicy="no-referrer-when-downgrade"
              ></iframe>
              <div className="absolute top-4 left-4 bg-black/80 backdrop-blur-md p-4 space-y-2 border border-white/10">
                <div className="flex items-center space-x-2 text-gold-500">
                  <MapPin className="w-4 h-4" />
                  <span className="text-[10px] font-bold uppercase tracking-widest">Our Boutique</span>
                </div>
                <p className="text-xs uppercase tracking-tighter">Suite 12, Luxury Plaza, Lagos, Nigeria</p>
              </div>
            </div>
          </div>

          <div className="bg-white/5 border border-white/10 p-12 space-y-8 h-fit">
            <h2 className="text-2xl font-display font-bold uppercase tracking-widest">Send a Message</h2>
            <form className="space-y-6">
              <div className="space-y-4">
                <input 
                  type="text" 
                  placeholder="FULL NAME" 
                  className="w-full bg-transparent border-b border-white/20 py-4 text-xs tracking-widest outline-none focus:border-gold-500 transition-colors uppercase"
                />
                <input 
                  type="email" 
                  placeholder="EMAIL ADDRESS" 
                  className="w-full bg-transparent border-b border-white/20 py-4 text-xs tracking-widest outline-none focus:border-gold-500 transition-colors uppercase"
                />
                <input 
                  type="text" 
                  placeholder="SUBJECT (BESPOKE ORDER / SUPPORT)" 
                  className="w-full bg-transparent border-b border-white/20 py-4 text-xs tracking-widest outline-none focus:border-gold-500 transition-colors uppercase"
                />
                <textarea 
                  rows={4}
                  placeholder="YOUR MESSAGE" 
                  className="w-full bg-transparent border-b border-white/20 py-4 text-xs tracking-widest outline-none focus:border-gold-500 transition-colors uppercase resize-none"
                ></textarea>
              </div>
              <button className="w-full bg-gold-500 text-black py-4 font-bold uppercase tracking-widest flex items-center justify-center space-x-2 hover:bg-gold-400 transition-colors">
                <span>Send via Messenger</span>
                <Send className="w-4 h-4" />
              </button>
            </form>
            <div className="pt-8 border-t border-white/5 text-center">
              <p className="text-[10px] text-gray-500 uppercase tracking-widest mb-4">Or Use WhatsApp Direct</p>
              <a 
                href="https://wa.me/2347030146879" 
                className="inline-flex items-center space-x-2 text-green-500 hover:text-green-400 transition-colors font-bold uppercase text-xs tracking-widest"
              >
                <span>Live Chat Support</span>
                <ArrowRight className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function ArrowRight({ className }: { className?: string }) {
  return (
    <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
    </svg>
  );
}
