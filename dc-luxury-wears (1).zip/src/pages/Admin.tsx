import { useState, useEffect } from "react";
import { LayoutDashboard, ShoppingBag, Users, Package, TrendingUp, Plus, Edit, Trash2 } from "lucide-react";
import { getProducts } from "../services/api";
import { Product } from "../types";

export default function Admin() {
  const [products, setProducts] = useState<Product[]>([]);
  const [activeTab, setActiveTab] = useState("products");

  useEffect(() => {
    getProducts().then(setProducts);
  }, []);

  const stats = [
    { label: "Total Revenue", value: "₦12.5M", icon: <TrendingUp className="w-5 h-5" />, color: "text-green-500" },
    { label: "Orders", value: "142", icon: <ShoppingBag className="w-5 h-5" />, color: "text-blue-500" },
    { label: "Customers", value: "856", icon: <Users className="w-5 h-5" />, color: "text-gold-500" },
    { label: "Products", value: products.length.toString(), icon: <Package className="w-5 h-5" />, color: "text-purple-500" },
  ];

  return (
    <div className="pt-32 pb-24 bg-black min-h-screen">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex justify-between items-center mb-12">
          <div>
            <h1 className="text-3xl font-display font-bold gold-text uppercase tracking-widest">Admin Control</h1>
            <p className="text-gray-500 text-xs uppercase tracking-tighter mt-1">Manage your luxury empire</p>
          </div>
          <button className="bg-gold-500 text-black px-6 py-2 text-xs font-bold uppercase tracking-widest flex items-center space-x-2">
            <Plus className="w-4 h-4" />
            <span>Add Product</span>
          </button>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
          {stats.map((stat, i) => (
            <div key={i} className="bg-white/5 border border-white/10 p-6 flex items-center space-x-4">
              <div className={`p-4 bg-white/10 rounded-xl ${stat.color}`}>{stat.icon}</div>
              <div>
                <p className="text-[10px] text-gray-500 uppercase tracking-widest">{stat.label}</p>
                <p className="text-xl font-bold">{stat.value}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Management Table */}
        <div className="bg-white/5 border border-white/10 overflow-hidden">
          <div className="flex border-b border-white/10">
            {["products", "orders", "customers"].map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-8 py-4 text-xs font-bold uppercase tracking-widest transition-colors ${
                  activeTab === tab ? "bg-gold-500 text-black" : "hover:bg-white/5 text-gray-500"
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-white/5 text-[10px] uppercase tracking-widest gold-text">
                <tr>
                  <th className="px-6 py-4">Product</th>
                  <th className="px-6 py-4">Category</th>
                  <th className="px-6 py-4">Price</th>
                  <th className="px-6 py-4">Stock</th>
                  <th className="px-6 py-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-sm">
                {products.map((p) => (
                  <tr key={p.id} className="hover:bg-white/5 transition-colors">
                    <td className="px-6 py-4 flex items-center space-x-4">
                      <img src={p.image} className="w-10 h-10 object-cover" alt="" />
                      <span className="font-bold">{p.name}</span>
                    </td>
                    <td className="px-6 py-4 text-gray-400 capitalize">{p.category}</td>
                    <td className="px-6 py-4 font-bold">₦{p.price.toLocaleString()}</td>
                    <td className="px-6 py-4">
                      <span className="bg-green-500/10 text-green-500 px-2 py-1 rounded text-[10px] font-bold">IN STOCK</span>
                    </td>
                    <td className="px-6 py-4 text-right space-x-2">
                      <button className="p-2 hover:text-gold-500 transition-colors"><Edit className="w-4 h-4" /></button>
                      <button className="p-2 hover:text-red-500 transition-colors"><Trash2 className="w-4 h-4" /></button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
