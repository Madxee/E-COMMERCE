import { motion } from "motion/react";
import { Award, ShieldCheck, Diamond, Zap } from "lucide-react";

export default function About() {
  return (
    <div className="pt-32 pb-24 bg-black min-h-screen">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center mb-32">
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            <h4 className="gold-text font-bold uppercase tracking-[0.3em] text-sm">Since 2018</h4>
            <h1 className="text-5xl md:text-7xl font-display font-bold leading-tight">THE LEGACY OF <br /><span className="gold-text">DC LUXURY</span></h1>
            <p className="text-gray-400 leading-loose uppercase text-xs tracking-widest">
              Founded in the heart of Lagos, DC Luxury Wears was born from a vision to bring world-class fashion and elite lifestyle essentials to the Nigerian market.
            </p>
            <p className="text-gray-400 leading-loose uppercase text-xs tracking-widest">
              We believe that luxury is not just about price, but about the story, the craftsmanship, and the feeling of wearing something designed with uncompromising excellence.
            </p>
            <div className="grid grid-cols-2 gap-8 pt-8">
              <div className="border-l-2 border-gold-500 pl-6">
                <p className="text-3xl font-display font-bold">5K+</p>
                <p className="text-[10px] text-gray-500 uppercase tracking-widest">Elite Clients</p>
              </div>
              <div className="border-l-2 border-gold-500 pl-6">
                <p className="text-3xl font-display font-bold">200+</p>
                <p className="text-[10px] text-gray-500 uppercase tracking-widest">Partner Brands</p>
              </div>
            </div>
          </motion.div>
          <div className="relative">
            <div className="aspect-[4/5] overflow-hidden border border-white/10 relative z-10">
              <img src="https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=800" className="w-full h-full object-cover" alt="Luxury suit" />
            </div>
            <div className="absolute -top-10 -right-10 w-full h-full bg-gold-500/5 -z-0"></div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-32">
          {[
            { icon: <Award />, title: "Quality Assurance", desc: "Every piece undergoes 12 stages of authenticity verification." },
            { icon: <ShieldCheck />, title: "Secure Payments", desc: "End-to-end encrypted transactions via leading gateways." },
            { icon: <Diamond />, title: "Elite Sourcing", desc: "Limited edition releases sourced from global fashion capitals." },
            { icon: <Zap />, title: "Express Logistics", desc: "Next-day delivery within Lagos and major cities." }
          ].map((feature, i) => (
            <div key={i} className="text-center space-y-4">
              <div className="w-12 h-12 bg-gold-500/10 rounded-full flex items-center justify-center mx-auto gold-text">
                {feature.icon}
              </div>
              <h3 className="text-xs font-bold uppercase tracking-widest">{feature.title}</h3>
              <p className="text-[10px] text-gray-500 uppercase leading-relaxed tracking-tighter">{feature.desc}</p>
            </div>
          ))}
        </div>

        <section className="bg-white/5 border border-white/10 p-20 text-center space-y-8 relative overflow-hidden">
          <div className="absolute -top-24 -left-24 w-64 h-64 bg-gold-500/10 rounded-full blur-[100px]"></div>
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="text-4xl font-display font-bold gold-text uppercase tracking-widest"
          >
            Redefine Your Presence
          </motion.h2>
          <p className="text-gray-400 max-w-xl mx-auto uppercase text-xs tracking-widest leading-loose">
            Join the elite circle of individuals who choose DC Luxury Wears for their fashion needs. Elevate your status with our curated collections.
          </p>
          <button className="bg-gold-500 text-black px-12 py-4 font-bold uppercase tracking-widest hover:bg-gold-400 transition-all">
            Join the Circle
          </button>
        </section>
      </div>
    </div>
  );
}
