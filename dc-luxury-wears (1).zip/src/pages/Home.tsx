import { useState, useEffect } from "react";
import { motion } from "motion/react";
import { ArrowRight, Star, ShoppingCart, Eye, Heart } from "lucide-react";
import { Link } from "react-router-dom";
import { getProducts } from "../services/api";
import { Product } from "../types";

export default function Home() {
  const [products, setProducts] = useState<Product[]>([]);

  useEffect(() => {
    getProducts().then(setProducts);
  }, []);

  const categories = [
    { name: "Men Fashion", image: "https://images.unsplash.com/photo-1617137984095-74e4e5e3613f?w=800", count: 124 },
    { name: "Women Fashion", image: "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=800", count: 86 },
    { name: "Shoes", image: "https://images.unsplash.com/photo-1549298916-b41d501d3772?w=800", count: 52 },
    { name: "Watches", image: "https://images.unsplash.com/photo-1547996160-81dfa63595aa?w=800", count: 43 },
    { name: "Bags", image: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=800", count: 31 },
    { name: "Perfumes", image: "https://images.unsplash.com/photo-1541643600914-78b084683601?w=800", count: 19 },
  ];

  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="relative h-[90vh] overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src="https://images.unsplash.com/photo-1441984904996-e0b6ba687e04?q=80&w=2070" 
            alt="Hero Background" 
            className="w-full h-full object-cover opacity-60"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black via-black/40 to-transparent"></div>
        </div>
        
        <div className="relative h-full max-w-7xl mx-auto px-6 flex flex-col justify-center">
          <motion.h4 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="gold-text font-bold uppercase tracking-[0.3em] mb-4 text-sm"
          >
            Exclusive Collection 2026
          </motion.h4>
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="text-6xl md:text-8xl font-display font-bold leading-tight mb-8"
          >
            LUXURY FASHION <br />
            <span className="gold-text">REDEFINED</span>
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="text-gray-300 max-w-xl text-lg mb-10 leading-relaxed"
          >
            Premium wears, accessories, gadgets, and lifestyle essentials curated for the elite. Experience the pinnacle of Nigerian craftsmanship.
          </motion.p>
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8 }}
            className="flex flex-wrap gap-4"
          >
            <Link to="/shop" className="bg-gold-500 text-black px-10 py-4 rounded-none font-bold uppercase tracking-widest hover:bg-gold-400 transition-all flex items-center group">
              Shop Now <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Link>
            <Link to="/explore" className="border border-white/20 bg-white/5 backdrop-blur-md px-10 py-4 rounded-none font-bold uppercase tracking-widest hover:bg-white/10 transition-all">
              Explore Collection
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Featured Categories */}
      <section className="py-24 bg-black">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-display font-bold gold-text uppercase tracking-widest mb-4">The Collections</h2>
            <div className="w-24 h-1 bg-gold-500 mx-auto"></div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-6">
            {categories.map((cat, i) => (
              <motion.div 
                key={i}
                whileHover={{ y: -10 }}
                className="group cursor-pointer"
              >
                <div className="relative aspect-[3/4] overflow-hidden border border-white/5">
                  <img src={cat.image} alt={cat.name} className="w-full h-full object-cover grayscale group-hover:grayscale-0 group-hover:scale-110 transition-all duration-700" />
                  <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-colors"></div>
                  <div className="absolute bottom-6 left-6 right-6 text-center">
                    <h3 className="text-sm font-bold uppercase tracking-widest mb-1">{cat.name}</h3>
                    <p className="text-[10px] text-gold-500 uppercase">{cat.count} Items</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-24 luxury-gradient">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex justify-between items-end mb-16">
            <div>
              <h2 className="text-3xl font-display font-bold uppercase tracking-widest gold-text">Featured Pieces</h2>
              <p className="text-gray-400 uppercase text-xs tracking-tighter mt-2">Selected exclusively for you</p>
            </div>
            <Link to="/shop" className="text-gold-500 uppercase text-xs font-bold tracking-widest hover:underline">View All Products</Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {products.map((product) => (
              <motion.div 
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="group"
              >
                <div className="relative aspect-square overflow-hidden bg-white/5 border border-white/10">
                  <img src={product.image} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  <div className="absolute top-4 right-4 flex flex-col space-y-2 translate-x-12 group-hover:translate-x-0 transition-transform duration-300">
                    <button className="p-2 bg-white text-black hover:bg-gold-500 transition-colors"><Heart className="w-4 h-4" /></button>
                    <button className="p-2 bg-white text-black hover:bg-gold-500 transition-colors"><Eye className="w-4 h-4" /></button>
                  </div>
                  <button className="absolute bottom-0 left-0 w-full bg-gold-500 text-black py-3 font-bold uppercase text-xs tracking-widest translate-y-full group-hover:translate-y-0 transition-transform duration-300 flex items-center justify-center space-x-2">
                    <ShoppingCart className="w-4 h-4" />
                    <span>Add to Cart</span>
                  </button>
                </div>
                <div className="mt-4 space-y-1">
                  <p className="text-[10px] text-gray-500 uppercase tracking-widest">{product.category}</p>
                  <h3 className="text-sm font-bold uppercase group-hover:gold-text transition-colors">{product.name}</h3>
                  <div className="flex justify-between items-center">
                    <span className="text-gold-500 font-bold">₦{product.price.toLocaleString()}</span>
                    <div className="flex items-center space-x-1">
                      <Star className="w-3 h-3 fill-gold-500 text-gold-500" />
                      <span className="text-[10px] text-gray-400">{product.rating}</span>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Flash Sale Section */}
      <section className="py-24 bg-white text-black overflow-hidden relative">
        <div className="absolute top-0 right-0 p-20 opacity-5">
           <h2 className="text-[200px] font-display font-bold whitespace-nowrap">FLASH SALE</h2>
        </div>
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
          <div>
            <span className="bg-black text-white px-4 py-1 text-[10px] font-bold uppercase tracking-widest mb-6 inline-block">Limited Time Offer</span>
            <h2 className="text-5xl font-display font-bold uppercase leading-tight mb-8">
              PREMIUM LUXURY EXCLUSIVE <br />
              <span className="text-gold-600">UP TO 40% OFF</span>
            </h2>
            <div className="flex space-x-8 mb-10">
              <div className="text-center">
                <p className="text-3xl font-display font-bold">02</p>
                <p className="text-[10px] uppercase font-bold text-gray-400 tracking-widest">Days</p>
              </div>
              <div className="text-center">
                <p className="text-3xl font-display font-bold">14</p>
                <p className="text-[10px] uppercase font-bold text-gray-400 tracking-widest">Hours</p>
              </div>
              <div className="text-center">
                <p className="text-3xl font-display font-bold">56</p>
                <p className="text-[10px] uppercase font-bold text-gray-400 tracking-widest">Mins</p>
              </div>
              <div className="text-center">
                <p className="text-3xl font-display font-bold">22</p>
                <p className="text-[10px] uppercase font-bold text-gray-400 tracking-widest">Secs</p>
              </div>
            </div>
            <Link to="/shop" className="inline-block bg-black text-white px-12 py-4 font-bold uppercase tracking-widest hover:bg-gold-700 transition-colors">
              Claim Offer
            </Link>
          </div>
          <motion.div 
            initial={{ scale: 1.1 }}
            whileInView={{ scale: 1 }}
            className="relative"
          >
            <div className="absolute -inset-4 border-2 border-black/5 rotate-3"></div>
            <img 
              src="https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=800" 
              alt="Flash Sale" 
              className="w-full h-full object-cover relative z-10 shadow-2xl"
            />
          </motion.div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 bg-black">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <motion.div 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            className="max-w-3xl mx-auto"
          >
            <Star className="w-8 h-8 gold-text mx-auto mb-8" />
            <p className="text-2xl font-display italic text-gray-300 leading-relaxed mb-8">
              "The quality of the DC Luxury collection is simply unmatched in Nigeria. Every piece I've purchased feels like a statement of success and elegance."
            </p>
            <div className="flex items-center justify-center space-x-3">
              <div className="w-10 h-10 rounded-full bg-gold-500 flex items-center justify-center font-bold text-black">OO</div>
              <div className="text-left font-display">
                <p className="text-sm font-bold uppercase tracking-widest">Olumide Okezie</p>
                <p className="text-[10px] gold-text uppercase">Verified Client</p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="py-24 border-t border-white/5 luxury-gradient">
        <div className="max-w-2xl mx-auto px-6 text-center">
          <h2 className="text-3xl font-display font-bold uppercase gold-text tracking-widest mb-4">Elite Newsletter</h2>
          <p className="text-gray-400 text-sm mb-8 uppercase tracking-tighter">Be the first to see our newest releases and exclusive events.</p>
          <div className="flex border border-white/10 p-1 bg-white/5 backdrop-blur-sm">
            <input 
              type="email" 
              placeholder="YOUR EMAIL ADDRESS" 
              className="bg-transparent border-none outline-none flex-1 px-6 text-sm text-white py-4"
            />
            <button className="bg-gold-500 text-black px-8 py-4 font-bold uppercase text-xs tracking-widest hover:bg-gold-400 transition-colors">
              Subscribe
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
