import { useState, useEffect } from "react";
import { Search, Filter, ChevronDown, ShoppingCart, Heart, Eye, SlidersHorizontal } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { getProducts, getCategories } from "../services/api";
import { Product } from "../types";

export default function Shop() {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  const [search, setSearch] = useState("");
  const [sortBy, setSortBy] = useState("Recommended");
  const [showFilters, setShowFilters] = useState(false);

  useEffect(() => {
    getProducts().then(setProducts);
    getCategories().then(setCategories);
  }, []);

  const filteredProducts = products.filter(p => {
    const matchesCategory = selectedCategory === "All" || p.category === selectedCategory;
    const matchesSearch = p.name.toLowerCase().includes(search.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="pt-32 pb-24 bg-black min-h-screen">
      <div className="max-w-7xl mx-auto px-6">
        <header className="mb-12">
          <h1 className="text-4xl font-display font-bold gold-text uppercase tracking-[0.2em] mb-4 text-center">Exclusive Collection</h1>
          <p className="text-gray-500 text-center uppercase text-xs tracking-widest font-medium">Browse our full range of luxury items</p>
        </header>

        {/* Toolbar */}
        <div className="flex flex-col md:flex-row justify-between items-center bg-white/5 border border-white/10 p-4 mb-12 gap-4">
          <div className="flex items-center space-x-4 w-full md:w-auto">
            <button 
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center space-x-2 text-xs uppercase font-bold tracking-widest border border-white/10 px-4 py-2 hover:bg-gold-500 hover:text-black transition-all"
            >
              <SlidersHorizontal className="w-4 h-4" />
              <span>Filters</span>
            </button>
            <div className="relative flex-1 md:w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <input 
                type="text" 
                placeholder="SEARCH PRODUCTS..." 
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full bg-black/40 border border-white/10 rounded-none py-2 pl-10 pr-4 text-[10px] uppercase tracking-widest focus:border-gold-500 transition-colors outline-none"
              />
            </div>
          </div>

          <div className="flex items-center space-x-4 w-full md:w-auto overflow-x-auto pb-2 md:pb-0 scrollbar-hide">
            {["All", ...categories].map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`text-[10px] uppercase font-bold tracking-widest px-4 py-2 whitespace-nowrap transition-all ${
                  selectedCategory === cat ? "bg-gold-500 text-black" : "text-gray-400 hover:text-gold-500"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="relative group w-full md:w-auto">
            <button className="flex items-center space-x-2 text-xs uppercase font-bold tracking-widest border border-white/10 px-4 py-2 w-full justify-between">
              <span>Sort: {sortBy}</span>
              <ChevronDown className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-8 gap-y-16">
          <AnimatePresence mode="popLayout">
            {filteredProducts.map((product) => (
              <motion.div 
                layout
                key={product.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.4 }}
                className="group"
              >
                <div className="relative aspect-[4/5] overflow-hidden bg-white/5 border border-white/10">
                  <img src={product.image} alt={product.name} className="w-full h-full object-cover group-hover:scale-110 transition-all duration-700" />
                  <div className="absolute top-4 right-4 flex flex-col space-y-2 translate-x-12 group-hover:translate-x-0 transition-transform duration-300">
                    <button className="p-2 bg-white text-black hover:bg-gold-500 transition-colors shadow-lg"><Heart className="w-4 h-4" /></button>
                    <button className="p-2 bg-white text-black hover:bg-gold-500 transition-colors shadow-lg"><Eye className="w-4 h-4" /></button>
                  </div>
                  <button className="absolute bottom-0 left-0 w-full bg-gold-500 text-black py-4 font-bold uppercase text-xs tracking-[0.2em] translate-y-full group-hover:translate-y-0 transition-transform duration-300 flex items-center justify-center space-x-2">
                    <ShoppingCart className="w-4 h-4" />
                    <span>Inquire Now</span>
                  </button>
                </div>
                <div className="mt-6 space-y-2 text-center">
                  <p className="text-[10px] text-gray-500 uppercase tracking-[0.3em] font-medium">{product.category}</p>
                  <h3 className="text-sm font-bold uppercase group-hover:gold-text transition-colors tracking-widest">{product.name}</h3>
                  <div className="flex flex-col items-center">
                    <span className="text-gold-500 font-bold text-lg">₦{product.price.toLocaleString()}</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {filteredProducts.length === 0 && (
          <div className="text-center py-24 border border-dashed border-white/10">
            <Search className="w-12 h-12 text-gray-700 mx-auto mb-4" />
            <h3 className="text-xl font-display uppercase tracking-widest font-bold">No pieces found</h3>
            <p className="text-gray-500 text-sm mt-2">Adjust your filters or search terms</p>
          </div>
        )}
      </div>
    </div>
  );
}
