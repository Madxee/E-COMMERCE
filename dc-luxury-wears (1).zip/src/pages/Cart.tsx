import { Link } from "react-router-dom";
import { Trash2, Plus, Minus, ShoppingBag, ArrowRight } from "lucide-react";
import { useCart } from "../context/CartContext";
import { motion } from "motion/react";

export default function Cart() {
  const { cart, removeFromCart, updateQuantity, total } = useCart();

  if (cart.length === 0) {
    return (
      <div className="pt-32 pb-24 text-center min-h-screen">
        <ShoppingBag className="w-16 h-16 text-gray-700 mx-auto mb-6" />
        <h2 className="text-3xl font-display font-bold uppercase tracking-widest mb-4">Your Bag is Empty</h2>
        <p className="text-gray-500 mb-8 max-w-md mx-auto">Explore our exclusive collections and find the perfect addition to your luxury lifestyle.</p>
        <Link to="/shop" className="bg-gold-500 text-black px-12 py-4 font-bold uppercase tracking-widest hover:bg-gold-400">
          Continue Shopping
        </Link>
      </div>
    );
  }

  return (
    <div className="pt-32 pb-24 bg-black min-h-screen">
      <div className="max-w-7xl mx-auto px-6">
        <h1 className="text-4xl font-display font-bold gold-text uppercase tracking-widest mb-12">Shopping Bag</h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          <div className="lg:col-span-2 space-y-8">
            {cart.map((item) => (
              <motion.div 
                layout
                key={item.id}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-6 bg-white/5 border border-white/10 p-6"
              >
                <div className="w-32 h-32 shrink-0 overflow-hidden border border-white/10">
                  <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                </div>
                <div className="flex-1 space-y-2 text-center sm:text-left">
                  <p className="text-[10px] text-gray-500 uppercase tracking-widest">{item.category}</p>
                  <h3 className="font-bold uppercase tracking-widest">{item.name}</h3>
                  <p className="text-gold-500 font-bold">₦{item.price.toLocaleString()}</p>
                </div>
                <div className="flex items-center space-x-4 border border-white/10 px-4 py-2">
                  <button onClick={() => updateQuantity(item.id, item.quantity - 1)} className="hover:text-gold-500"><Minus className="w-4 h-4" /></button>
                  <span className="text-sm font-bold w-4 text-center">{item.quantity}</span>
                  <button onClick={() => updateQuantity(item.id, item.quantity + 1)} className="hover:text-gold-500"><Plus className="w-4 h-4" /></button>
                </div>
                <div className="text-right sm:w-24">
                  <p className="font-bold">₦{(item.price * item.quantity).toLocaleString()}</p>
                  <button onClick={() => removeFromCart(item.id)} className="text-red-500 hover:text-red-400 mt-2">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </motion.div>
            ))}
          </div>

          <div className="space-y-6">
            <div className="bg-white/5 border border-white/10 p-8 space-y-6">
              <h3 className="text-xl font-display font-bold uppercase tracking-widest border-b border-white/10 pb-4">Order Summary</h3>
              <div className="space-y-4">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400 uppercase tracking-tighter">Subtotal</span>
                  <span className="font-bold">₦{total.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400 uppercase tracking-tighter">Shipping</span>
                  <span className="text-gold-500 font-bold uppercase tracking-widest">Calculated at Checkout</span>
                </div>
                <div className="border-t border-white/10 pt-4 flex justify-between items-end">
                  <span className="text-sm font-bold uppercase tracking-widest">Total</span>
                  <span className="text-2xl font-bold gold-text">₦{total.toLocaleString()}</span>
                </div>
              </div>
              <Link to="/checkout" className="w-full bg-gold-500 text-black py-4 font-bold uppercase tracking-widest flex items-center justify-center space-x-2 hover:bg-gold-400 transition-colors">
                <span>Secure Checkout</span>
                <ArrowRight className="w-5 h-5" />
              </Link>
            </div>
            
            <div className="bg-white/5 border border-white/10 p-6 text-center space-y-3">
              <p className="text-[10px] uppercase font-bold tracking-widest text-gray-500">Available Payment Methods</p>
              <div className="flex justify-center space-x-4 grayscale opacity-50">
                <img src="https://upload.wikimedia.org/wikipedia/commons/b/b5/PayPal.svg" className="h-4" alt="Paypal" />
                <img src="https://upload.wikimedia.org/wikipedia/commons/b/b7/MasterCard_Logo.svg" className="h-4" alt="Mastercard" />
                <img src="https://upload.wikimedia.org/wikipedia/commons/5/5e/Visa_Inc._logo.svg" className="h-4" alt="Visa" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
