import { useState } from "react";
import { useCart } from "../context/CartContext";
import { Lock, ChevronLeft, CreditCard, Landmark, Truck } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";

export default function Checkout() {
  const { cart, total, clearCart } = useCart();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    state: "",
    city: "",
    address: "",
    paymentMethod: "paystack"
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate payment processing
    alert("Processing payment via " + formData.paymentMethod.toUpperCase() + "...");
    setTimeout(() => {
      clearCart();
      navigate("/");
      alert("Order Placed Successfully! DC LUXURY WEARS thanks you for your patronage.");
    }, 2000);
  };

  return (
    <div className="pt-32 pb-24 bg-black min-h-screen">
      <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-16">
        <div>
          <Link to="/cart" className="flex items-center text-xs text-gray-500 uppercase tracking-widest hover:text-gold-500 mb-8">
            <ChevronLeft className="w-4 h-4 mr-2" />
            Back to Bag
          </Link>
          <h1 className="text-3xl font-display font-bold uppercase tracking-widest mb-8">Checkout</h1>
          
          <form onSubmit={handleSubmit} className="space-y-8">
            <section className="space-y-4">
              <h2 className="text-xs font-bold uppercase tracking-widest gold-text flex items-center">
                <span className="w-6 h-6 rounded-full border border-gold-500 flex items-center justify-center mr-3">1</span>
                Contact Information
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <input 
                  type="text" 
                  placeholder="FULL NAME" 
                  required
                  className="bg-white/5 border border-white/10 p-4 text-xs uppercase tracking-widest outline-none focus:border-gold-500"
                  value={formData.fullName}
                  onChange={e => setFormData({...formData, fullName: e.target.value})}
                />
                <input 
                  type="email" 
                  placeholder="EMAIL ADDRESS" 
                  required
                  className="bg-white/5 border border-white/10 p-4 text-xs uppercase tracking-widest outline-none focus:border-gold-500"
                  value={formData.email}
                  onChange={e => setFormData({...formData, email: e.target.value})}
                />
                <input 
                  type="tel" 
                  placeholder="PHONE NUMBER" 
                  required
                  className="bg-white/5 border border-white/10 p-4 text-xs uppercase tracking-widest outline-none focus:border-gold-500 md:col-span-2"
                  value={formData.phone}
                  onChange={e => setFormData({...formData, phone: e.target.value})}
                />
              </div>
            </section>

            <section className="space-y-4">
              <h2 className="text-xs font-bold uppercase tracking-widest gold-text flex items-center">
                <span className="w-6 h-6 rounded-full border border-gold-500 flex items-center justify-center mr-3">2</span>
                Delivery Address
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <input 
                  type="text" 
                  placeholder="STATE" 
                  required
                  className="bg-white/5 border border-white/10 p-4 text-xs uppercase tracking-widest outline-none focus:border-gold-500"
                  value={formData.state}
                  onChange={e => setFormData({...formData, state: e.target.value})}
                />
                <input 
                  type="text" 
                  placeholder="CITY" 
                  required
                  className="bg-white/5 border border-white/10 p-4 text-xs uppercase tracking-widest outline-none focus:border-gold-500"
                  value={formData.city}
                  onChange={e => setFormData({...formData, city: e.target.value})}
                />
                <textarea 
                  placeholder="STREET ADDRESS" 
                  required
                  rows={3}
                  className="bg-white/5 border border-white/10 p-4 text-xs uppercase tracking-widest outline-none focus:border-gold-500 md:col-span-2"
                  value={formData.address}
                  onChange={e => setFormData({...formData, address: e.target.value})}
                ></textarea>
              </div>
            </section>

            <section className="space-y-4">
              <h2 className="text-xs font-bold uppercase tracking-widest gold-text flex items-center">
                <span className="w-6 h-6 rounded-full border border-gold-500 flex items-center justify-center mr-3">3</span>
                Payment Method
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[
                  { id: 'paystack', label: 'Paystack', icon: <CreditCard className="w-4 h-4" /> },
                  { id: 'flutterwave', label: 'Flutterwave', icon: <CreditCard className="w-4 h-4" /> },
                  { id: 'transfer', label: 'Bank Transfer', icon: <Landmark className="w-4 h-4" /> },
                  { id: 'cod', label: 'Cash on Delivery', icon: <Truck className="w-4 h-4" /> }
                ].map(method => (
                  <label 
                    key={method.id}
                    className={`flex items-center p-4 border cursor-pointer transition-all ${
                      formData.paymentMethod === method.id 
                        ? 'border-gold-500 bg-gold-500/5' 
                        : 'border-white/10 bg-white/5 hover:border-white/30'
                    }`}
                  >
                    <input 
                      type="radio" 
                      name="payment" 
                      className="hidden" 
                      value={method.id}
                      checked={formData.paymentMethod === method.id}
                      onChange={() => setFormData({...formData, paymentMethod: method.id})}
                    />
                    <div className={`p-2 rounded-lg mr-3 ${formData.paymentMethod === method.id ? 'bg-gold-500 text-black' : 'bg-white/10 text-white'}`}>
                      {method.icon}
                    </div>
                    <span className="text-xs font-bold uppercase tracking-widest">{method.label}</span>
                  </label>
                ))}
              </div>
            </section>

            <button type="submit" className="w-full bg-gold-500 text-black py-4 font-bold uppercase tracking-[0.3em] flex items-center justify-center space-x-2 mt-12 hover:bg-gold-400">
              <Lock className="w-4 h-4" />
              <span>Complete Order — ₦{total.toLocaleString()}</span>
            </button>
          </form>
        </div>

        <div className="bg-white/5 border border-white/10 p-8 h-fit lg:sticky lg:top-32">
          <h3 className="text-xl font-display font-bold uppercase tracking-widest mb-8 border-b border-white/10 pb-4">In Your Bag</h3>
          <div className="space-y-6 mb-8 max-h-96 overflow-y-auto pr-4 scrollbar-hide">
            {cart.map(item => (
              <div key={item.id} className="flex space-x-4">
                <div className="w-20 h-20 shrink-0 border border-white/10">
                  <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                </div>
                <div className="flex-1 space-y-1">
                  <h4 className="text-xs font-bold uppercase tracking-widest">{item.name}</h4>
                  <p className="text-[10px] text-gray-500 uppercase">{item.quantity} × ₦{item.price.toLocaleString()}</p>
                </div>
                <div className="text-xs font-bold">₦{(item.price * item.quantity).toLocaleString()}</div>
              </div>
            ))}
          </div>
          <div className="space-y-4 border-t border-white/10 pt-6">
            <div className="flex justify-between text-sm uppercase tracking-tighter">
              <span className="text-gray-400">Subtotal</span>
              <span className="font-bold">₦{total.toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-sm uppercase tracking-tighter">
              <span className="text-gray-400">Luxury Delivery</span>
              <span className="text-gold-500 font-bold uppercase">Free</span>
            </div>
            <div className="flex justify-between items-end pt-4">
              <span className="text-xs font-bold uppercase tracking-widest text-gold-500">Order Total</span>
              <span className="text-3xl font-bold">₦{total.toLocaleString()}</span>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-white/10 flex items-center justify-center text-gray-500 space-x-4">
            <div className="flex items-center space-x-2 text-[10px] uppercase tracking-widest">
              <Lock className="w-3 h-3" />
              <span>Secure Checkout</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
