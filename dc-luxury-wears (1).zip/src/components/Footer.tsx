import { Link } from "react-router-dom";
import { Facebook, Instagram, Twitter, Mail, MapPin, Phone } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-black border-t border-gold-500/20 pt-20 pb-10">
      <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-4 gap-12">
        <div className="space-y-6">
          <h3 className="text-xl font-display gold-text font-bold uppercase tracking-widest">DC Luxury Wears</h3>
          <p className="text-gray-400 text-sm leading-relaxed">
            Redefining luxury fashion in Nigeria. Premium wears, accessories, and gadgets for the sophisticated lifestyle.
          </p>
          <div className="flex space-x-4">
            <a href="#" className="p-2 border border-white/10 rounded-full hover:border-gold-500 transition-colors"><Facebook className="w-4 h-4" /></a>
            <a href="#" className="p-2 border border-white/10 rounded-full hover:border-gold-500 transition-colors"><Instagram className="w-4 h-4" /></a>
            <a href="#" className="p-2 border border-white/10 rounded-full hover:border-gold-500 transition-colors"><Twitter className="w-4 h-4" /></a>
          </div>
        </div>

        <div className="space-y-6">
          <h4 className="text-sm font-bold uppercase tracking-widest gold-text">Quick Links</h4>
          <ul className="space-y-3 text-sm text-gray-400 uppercase tracking-tighter">
            <li><Link to="/shop" className="hover:text-gold-500 transition-colors">Shop All</Link></li>
            <li><Link to="/about" className="hover:text-gold-500 transition-colors">Our Story</Link></li>
            <li><Link to="/contact" className="hover:text-gold-500 transition-colors">Contact Us</Link></li>
            <li><Link to="/track" className="hover:text-gold-500 transition-colors">Order Tracking</Link></li>
          </ul>
        </div>

        <div className="space-y-6">
          <h4 className="text-sm font-bold uppercase tracking-widest gold-text">Categories</h4>
          <ul className="space-y-3 text-sm text-gray-400 uppercase tracking-tighter">
            <li><Link to="/shop" className="hover:text-gold-500 transition-colors">Men's Wear</Link></li>
            <li><Link to="/shop" className="hover:text-gold-500 transition-colors">Women's Wear</Link></li>
            <li><Link to="/shop" className="hover:text-gold-500 transition-colors">Watches</Link></li>
            <li><Link to="/shop" className="hover:text-gold-500 transition-colors">Accessories</Link></li>
          </ul>
        </div>

        <div className="space-y-6">
          <h4 className="text-sm font-bold uppercase tracking-widest gold-text">Contact</h4>
          <ul className="space-y-4 text-sm text-gray-400">
            <li className="flex items-start space-x-3">
              <MapPin className="w-5 h-5 gold-text shrink-0" />
              <span>Suite 12, Luxury Plaza, Lagos, Nigeria</span>
            </li>
            <li className="flex items-center space-x-3">
              <Phone className="w-5 h-5 gold-text shrink-0" />
              <span>+234 703 014 6879</span>
            </li>
            <li className="flex items-center space-x-3">
              <Mail className="w-5 h-5 gold-text shrink-0" />
              <span>contact@dcluxury.com</span>
            </li>
          </ul>
        </div>
      </div>
      <div className="max-w-7xl mx-auto px-6 mt-20 pt-8 border-t border-white/5 text-center text-xs text-gray-500 uppercase tracking-widest">
        &copy; 2026 DC LUXURY WEARS — ALL RIGHTS RESERVED.
      </div>
    </footer>
  );
}
