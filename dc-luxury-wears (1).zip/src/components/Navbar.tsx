import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { ShoppingCart, Menu, X, User, Search, Heart } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${scrolled ? "bg-black/90 backdrop-blur-md border-b border-gold-500/20 py-4" : "bg-transparent py-6"}`}>
      <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
        <Link to="/" className="text-2xl font-display font-bold gold-text tracking-widest uppercase">
          DC Luxury
        </Link>

        {/* Desktop Menu */}
        <div className="hidden md:flex space-x-8 items-center text-sm uppercase tracking-tighter">
          <Link to="/" className="hover:text-gold-500 transition-colors">Home</Link>
          <Link to="/shop" className="hover:text-gold-500 transition-colors">Shop</Link>
          <Link to="/about" className="hover:text-gold-500 transition-colors">About</Link>
          <Link to="/contact" className="hover:text-gold-500 transition-colors">Contact</Link>
        </div>

        <div className="flex items-center space-x-6">
          <Search className="w-5 h-5 cursor-pointer hover:text-gold-500 transition-colors" />
          <Link to="/cart" className="relative">
            <ShoppingCart className="w-5 h-5 hover:text-gold-500 transition-colors" />
            <span className="absolute -top-2 -right-2 bg-gold-500 text-black text-[10px] font-bold px-1.5 rounded-full">0</span>
          </Link>
          <Link to="/login">
            <User className="w-5 h-5 hover:text-gold-500 transition-colors" />
          </Link>
          <button className="md:hidden" onClick={() => setIsOpen(!isOpen)}>
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-full left-0 w-full bg-black border-b border-gold-500/20 py-8 px-6 md:hidden"
          >
            <div className="flex flex-col space-y-6 text-center uppercase tracking-widest">
              <Link to="/" onClick={() => setIsOpen(false)}>Home</Link>
              <Link to="/shop" onClick={() => setIsOpen(false)}>Shop</Link>
              <Link to="/about" onClick={() => setIsOpen(false)}>About</Link>
              <Link to="/contact" onClick={() => setIsOpen(false)}>Contact</Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
