export interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  image: string;
  description: string;
  rating: number;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'user' | 'admin';
}

export interface CartItem extends Product {
  quantity: number;
}

export interface Order {
  id: string;
  userId: string;
  items: CartItem[];
  total: number;
  status: 'pending' | 'processing' | 'shipped' | 'delivered';
  createdAt: string;
  address: {
    fullName: string;
    email: string;
    phone: string;
    state: string;
    city: string;
    address: string;
  };
  paymentMethod: 'paystack' | 'flutterwave' | 'transfer' | 'cod';
}
