import { Product } from "../types";

export const getProducts = async (): Promise<Product[]> => {
  const response = await fetch("/api/products");
  return response.json();
};

export const getCategories = async (): Promise<string[]> => {
  const response = await fetch("/api/categories");
  return response.json();
};

export const sendChatMessage = async (message: string) => {
  const response = await fetch("/api/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ message }),
  });
  return response.json();
};
