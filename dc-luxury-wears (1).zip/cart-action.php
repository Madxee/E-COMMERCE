<?php
// DC LUXURY WEARS - Cart Action Handler
session_start();

if(!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

$action = isset($_GET['action']) ? $_GET['action'] : '';

if($action === 'add') {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $price = $_POST['price'];
    $image = $_POST['image'];

    if(isset($_SESSION['cart'][$id])) {
        $_SESSION['cart'][$id]['quantity']++;
    } else {
        $_SESSION['cart'][$id] = [
            'name' => $name,
            'price' => $price,
            'image' => $image,
            'quantity' => 1
        ];
    }
    echo json_encode(['status' => 'success', 'count' => count($_SESSION['cart'])]);
}

if($action === 'remove') {
    $id = $_POST['id'];
    unset($_SESSION['cart'][$id]);
    header('Location: cart.php');
}

if($action === 'update') {
    $id = $_POST['id'];
    $qty = (int)$_POST['quantity'];
    if($qty > 0) {
        $_SESSION['cart'][$id]['quantity'] = $qty;
    }
    header('Location: cart.php');
}
?>
