<?php
session_start();
if(!isset($_SESSION['admin_logged_in'])) { header('Location: login.php'); exit; }
require_once '../includes/db.php';

$products = $pdo->query("SELECT * FROM products")->fetchAll();
$orders = $pdo->query("SELECT * FROM orders ORDER BY created_at DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>DC LUXURY - Control Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
</head>
<body class="bg-black text-white min-h-screen">
    <div class="flex h-screen overflow-hidden">
        <!-- Sidebar -->
        <aside class="w-64 border-r border-white/10 p-8 hidden md:block">
            <h2 class="text-xl font-serif gold-text font-bold uppercase mb-12">DC Control</h2>
            <nav class="space-y-6">
                <a href="#" class="flex items-center space-x-3 text-gold-500 font-bold uppercase text-[10px] tracking-widest"><i data-lucide="layout-dashboard" class="w-4 h-4"></i> <span>Stats</span></a>
                <a href="#" class="flex items-center space-x-3 text-gray-400 hover:text-white uppercase text-[10px] tracking-widest transition-colors"><i data-lucide="package" class="w-4 h-4"></i> <span>Catalog</span></a>
                <a href="#" class="flex items-center space-x-3 text-gray-400 hover:text-white uppercase text-[10px] tracking-widest transition-colors"><i data-lucide="shopping-bag" class="w-4 h-4"></i> <span>Orders</span></a>
                <a href="logout.php" class="flex items-center space-x-3 text-red-500 uppercase text-[10px] tracking-widest pt-12"><i data-lucide="log-out" class="w-4 h-4"></i> <span>Exit System</span></a>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="flex-1 overflow-y-auto p-12">
            <div class="flex justify-between items-center mb-12">
                <h1 class="text-3xl font-serif gold-text font-bold uppercase">Executive Dashboard</h1>
                <button class="bg-gold-500 text-black px-6 py-2 text-[10px] font-bold uppercase tracking-widest">New Piece</button>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
                <div class="bg-white/5 border border-white/10 p-8">
                    <p class="text-[10px] text-gray-500 uppercase tracking-widest mb-2">Total Managed</p>
                    <p class="text-3xl font-serif font-bold uppercase"><?php echo count($products); ?> Pieces</p>
                </div>
                <div class="bg-white/5 border border-white/10 p-8">
                    <p class="text-[10px] text-gray-500 uppercase tracking-widest mb-2">Active Orders</p>
                    <p class="text-3xl font-serif font-bold uppercase">12 Current</p>
                </div>
                <div class="bg-white/5 border border-white/10 p-8">
                    <p class="text-[10px] text-gray-500 uppercase tracking-widest mb-2">Revenue (MTD)</p>
                    <p class="text-3xl font-serif font-bold uppercase text-green-500">₦4.2M</p>
                </div>
            </div>

            <!-- Product Table -->
            <div class="bg-white/5 border border-white/10">
                <div class="p-6 border-b border-white/10 flex justify-between">
                    <h3 class="font-bold uppercase text-xs tracking-widest">Global Inventory</h3>
                </div>
                <table class="w-full text-left">
                    <thead class="text-[10px] uppercase tracking-widest text-gold-500 bg-white/5">
                        <tr>
                            <th class="px-6 py-4">Piece</th>
                            <th class="px-6 py-4">Price</th>
                            <th class="px-6 py-4 text-right">Action</th>
                        </tr>
                    </thead>
                    <tbody class="text-xs uppercase tracking-tighter divide-y divide-white/5">
                        <?php foreach($products as $p): ?>
                            <tr class="hover:bg-white/5 transition-colors">
                                <td class="px-6 py-4 font-bold"><?php echo $p['name']; ?></td>
                                <td class="px-6 py-4">₦<?php echo number_format($p['price']); ?></td>
                                <td class="px-6 py-4 text-right">
                                    <button class="text-gold-500 hover:underline">Revise</button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
    <script>lucide.createIcons();</script>
</body>
</html>
