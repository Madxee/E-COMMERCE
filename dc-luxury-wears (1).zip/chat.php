<?php
// DC LUXURY WEARS - AI Chatbot Handler (PHP)
header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$message = isset($input['message']) ? $input['message'] : '';

// You would typically get this from an environment variable or config file
$apiKey = 'YOUR_GEMINI_API_KEY_HERE'; 

if (empty($message)) {
    echo json_encode(['text' => 'How can I assist you today?']);
    exit;
}

// In a shared hosting environment, you might use cURL to call Gemini API
// This is a conceptual implementation of the API call
$url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=" . $apiKey;

$data = [
    "contents" => [[
        "parts" => [[
            "text" => "You are the DC LUXURY WEARS Assistant. DC LUXURY WEARS is a luxury fashion brand in Nigeria. We sell Men wears, Women wears, Shoes, Wristwatches, Bags, Accessories, Perfumes, Luxury gadgets. Currency: Nigerian Naira (₦). WhatsApp: +2347030146879. Be polite, luxurious, and helpful. User Message: " . $message
        ]]
    ]]
];

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

$response = curl_exec($ch);
curl_close($ch);

$result = json_decode($response, true);
$reply = isset($result['candidates'][0]['content']['parts'][0]['text']) 
    ? $result['candidates'][0]['content']['parts'][0]['text'] 
    : "I am having trouble connecting to my luxury database. Please contact us on WhatsApp (+2347030146879) for immediate support.";

echo json_encode(['text' => $reply]);
?>
