<?php 
require_once 'includes/db.php';
include 'includes/header.php';

$category_filter = isset($_GET['category']) ? $_GET['category'] : 'All';
$search = isset($_GET['search']) ? $_GET['search'] : '';

$query = "SELECT * FROM products WHERE 1=1";
if($category_filter !== 'All') { $query .= " AND category_id = (SELECT id FROM categories WHERE name = :cat)"; }
if($search !== '') { $query .= " AND name LIKE :search"; }

$stmt = $pdo->prepare($query);
if($category_filter !== 'All') { $stmt->bindParam(':cat', $category_filter); }
if($search !== '') { $search_val = "%$search%"; $stmt->bindParam(':search', $search_val); }
$stmt->execute();
$products = $stmt->fetchAll();

$categories_stmt = $pdo->query("SELECT * FROM categories");
$categories = $categories_stmt->fetchAll();
?>

<div class="pt-32 pb-24 bg-black min-h-screen">
    <div class="max-w-7xl mx-auto px-6">
        <header class="mb-12 text-center">
            <h1 class="text-4xl font-display font-bold gold-text uppercase tracking-widest mb-4">Elite Catalogue</h1>
            <div class="w-16 h-0.5 bg-gold-500 mx-auto"></div>
        </header>

        <!-- Filters -->
        <div class="flex flex-col md:flex-row justify-between items-center bg-white/5 border border-white/10 p-4 mb-12 gap-4">
            <form action="shop.php" method="GET" class="flex items-center space-x-4 w-full md:w-auto">
                <div class="relative flex-1 md:w-64">
                    <i data-lucide="search" class="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500"></i>
                    <input type="text" name="search" placeholder="SEARCH PIECES..." value="<?php echo htmlspecialchars($search); ?>" class="w-full bg-black/40 border border-white/10 rounded-none py-2 pl-10 pr-4 text-[10px] uppercase tracking-widest focus:border-gold-500 text-white outline-none">
                </div>
            </form>

            <div class="flex items-center space-x-4 w-full md:w-auto overflow-x-auto pb-2 md:pb-0 scrollbar-hide text-white">
                <a href="shop.php" class="<?php echo $category_filter === 'All' ? 'bg-gold-500 text-black' : 'text-gray-400'; ?> text-[10px] uppercase font-bold tracking-widest px-4 py-2 whitespace-nowrap transition-all">All</a>
                <?php foreach($categories as $cat): ?>
                    <a href="shop.php?category=<?php echo urlencode($cat['name']); ?>" class="<?php echo $category_filter === $cat['name'] ? 'bg-gold-500 text-black' : 'text-gray-400'; ?> text-[10px] uppercase font-bold tracking-widest px-4 py-2 whitespace-nowrap transition-all"><?php echo $cat['name']; ?></a>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Products -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            <?php foreach($products as $p): ?>
                <div class="group">
                    <div class="relative aspect-[4/5] overflow-hidden bg-white/5 border border-white/10">
                        <img src="<?php echo $p['image']; ?>" class="w-full h-full object-cover group-hover:scale-110 transition-all duration-700">
                        <a href="product.php?id=<?php echo $p['id']; ?>" class="absolute bottom-0 left-0 w-full bg-gold-500 text-black py-4 font-bold uppercase text-xs tracking-widest translate-y-full group-hover:translate-y-0 transition-transform duration-300 text-center">Inquire Piece</a>
                    </div>
                    <div class="mt-6 text-center space-y-1">
                        <h3 class="text-sm font-bold uppercase text-white tracking-widest group-hover:gold-text transition-colors"><?php echo $p['name']; ?></h3>
                        <p class="text-gold-500 font-bold">₦<?php echo number_format($p['price']); ?></p>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
