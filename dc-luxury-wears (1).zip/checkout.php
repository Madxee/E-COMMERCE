<?php 
session_start();
require_once 'includes/db.php';
include 'includes/header.php';
$cart = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];
$total = 0;
foreach($cart as $item) { $total += $item['price'] * $item['quantity']; }

if(empty($cart)) { header('Location: shop.php'); exit; }
?>

<div class="pt-32 pb-24 bg-black min-h-screen text-white">
    <div class="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-16">
        <div>
            <h1 class="text-3xl font-display font-bold uppercase tracking-widest mb-8 text-white">Checkout</h1>
            <form action="process-order.php" method="POST" class="space-y-8">
                <section class="space-y-4">
                    <h2 class="text-xs font-bold uppercase tracking-widest gold-text">1. Contact & Delivery</h2>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <input type="text" name="name" placeholder="FULL NAME" required class="bg-white/5 border border-white/10 p-4 text-xs uppercase tracking-widest outline-none focus:border-gold-500">
                        <input type="email" name="email" placeholder="EMAIL" required class="bg-white/5 border border-white/10 p-4 text-xs uppercase tracking-widest outline-none focus:border-gold-500">
                        <input type="tel" name="phone" placeholder="PHONE" required class="bg-white/5 border border-white/10 p-4 text-xs uppercase tracking-widest outline-none focus:border-gold-500 md:col-span-2">
                        <input type="text" name="state" placeholder="STATE" required class="bg-white/5 border border-white/10 p-4 text-xs uppercase tracking-widest outline-none focus:border-gold-500">
                        <input type="text" name="city" placeholder="CITY" required class="bg-white/5 border border-white/10 p-4 text-xs uppercase tracking-widest outline-none focus:border-gold-500">
                        <textarea name="address" placeholder="DELIVERY ADDRESS" required rows="3" class="bg-white/5 border border-white/10 p-4 text-xs uppercase tracking-widest outline-none focus:border-gold-500 md:col-span-2"></textarea>
                    </div>
                </section>

                <section class="space-y-4">
                    <h2 class="text-xs font-bold uppercase tracking-widest gold-text">2. Payment Method</h2>
                    <div class="grid grid-cols-2 gap-4">
                        <label class="flex items-center p-4 border border-white/10 bg-white/5 cursor-pointer hover:border-gold-500 transition-all">
                            <input type="radio" name="payment" value="paystack" checked class="mr-3 accent-gold-500">
                            <span class="text-[10px] font-bold uppercase tracking-widest">Paystack</span>
                        </label>
                        <label class="flex items-center p-4 border border-white/10 bg-white/5 cursor-pointer hover:border-gold-500 transition-all">
                            <input type="radio" name="payment" value="cod" class="mr-3 accent-gold-500">
                            <span class="text-[10px] font-bold uppercase tracking-widest">Cash on Delivery</span>
                        </label>
                    </div>
                </section>

                <input type="hidden" name="total" value="<?php echo $total; ?>">
                <button type="submit" class="w-full bg-gold-500 text-black py-4 font-bold uppercase tracking-[0.3em] hover:bg-gold-400 transition-colors">
                    Complete Order — ₦<?php echo number_format($total); ?>
                </button>
            </form>
        </div>

        <div class="bg-white/5 border border-white/10 p-8 h-fit lg:sticky lg:top-32">
            <h3 class="text-xl font-display font-bold uppercase mb-8 border-b border-white/10 pb-4">In Your Bag</h3>
            <div class="space-y-6 mb-8 max-h-[400px] overflow-y-auto pr-2">
                <?php foreach($cart as $item): ?>
                    <div class="flex space-x-4">
                        <div class="w-16 h-16 shrink-0 border border-white/10">
                            <img src="<?php echo $item['image']; ?>" class="w-full h-full object-cover">
                        </div>
                        <div class="flex-1">
                            <h4 class="text-[10px] font-bold uppercase tracking-widest"><?php echo $item['name']; ?></h4>
                            <p class="text-[10px] text-gray-500"><?php echo $item['quantity']; ?> × ₦<?php echo number_format($item['price']); ?></p>
                        </div>
                        <div class="text-[10px] font-bold">₦<?php echo number_format($item['price'] * $item['quantity']); ?></div>
                    </div>
                <?php endforeach; ?>
            </div>
            <div class="border-t border-white/10 pt-6 flex justify-between items-end">
                <span class="text-xs font-bold uppercase tracking-widest text-gold-500">Total Invoice</span>
                <span class="text-3xl font-bold">₦<?php echo number_format($total); ?></span>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
